package com.glats.clients.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.glats.clients.model.Clients;
import com.glats.clients.service.ClientsService;

@Controller
@RequestMapping("/clients")
public class ClientsController {

	@Autowired
	private ClientsService service;

	@RequestMapping("/register")
	public String register(ModelMap map) {
		map.addAttribute("clients", new Clients());

		return "clientsRegister";
	}

	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String insertEmployee(@ModelAttribute Clients clients) {

		Integer id= service.saveClient(clients);
		System.out.println(id);

		return "clientsRegister";
	}

	@RequestMapping("/all")
	public String showData(ModelMap map) {
		List<Clients> clts=service.getAllClients();
		for (Clients clients : clts) {
			System.out.println(clients);
		}

		map.addAttribute("clients", clts);
		return "clientsData";

	}

	@RequestMapping("/delete")
	public String deleteEmp(@RequestParam("clientId") Integer clientId,ModelMap map) {
		service.deleteClient(clientId);
		//constract finall message

		String msg="Clients"+clientId+"Deleted";

		//get new Data from database
		List<Clients> clts=service.getAllClients();
		//send to ui
		map.addAttribute("message",msg);
		map.addAttribute("clients", clts);
		return "clientsData";

	}

	// Edit operation
	@RequestMapping("/edit")
	public String showEdit(@RequestParam("clientId")Integer clientId,ModelMap map)
	{
		Clients clts=service.getOneClientById(clientId);
		map.addAttribute("clients", clts);
		return "clientsEdit";
	}


	// do update Opration
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String doUpdateData(@ModelAttribute Clients client,ModelMap map){
		service.updateClient(client); 
		String  msg="Clients'"+client.clientId+"'updated";

		List<Clients> clts=service.getAllClients(); 
        map.addAttribute("message",msg);
		map.addAttribute("employee", clts);

		return "clientsData"; 
	}

}
