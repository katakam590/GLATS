package com.glats.clients.dao;

import java.util.List;

import com.glats.clients.model.Clients;

public interface ClientsDao {
   public Integer saveClient(Clients clt) ;
   public void updateClient(Clients clt);
   public void deleteClient(Integer cltId);
   public Clients getOneClientById(Integer cltId);
   public List<Clients> getAllClients();
}
