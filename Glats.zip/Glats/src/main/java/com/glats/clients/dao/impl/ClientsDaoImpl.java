package com.glats.clients.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.glats.clients.dao.ClientsDao;
import com.glats.clients.model.Clients;

@Repository
public class ClientsDaoImpl implements ClientsDao {

	@Autowired
	private HibernateTemplate ht;

	@Override
	public Integer saveClient(Clients clt) {
		// TODO Auto-generated method stub
		return (Integer) ht.save(clt);
	}

	@Override
	public void updateClient(Clients clientId) {
		// TODO Auto-generated method stub
		ht.update(clientId);
	}

	@Override
	public void deleteClient(Integer clientId) {
		// TODO Auto-generated method stub
		Clients e=new Clients();
		e.setClientId(clientId);
		ht.delete(e);
	}

	@Override
	public Clients getOneClientById(Integer cltId) {
		// TODO Auto-generated method stub
		return ht.get(Clients.class, cltId);
	}

	@Override
	public List<Clients> getAllClients() {
		// TODO Auto-generated method stub
		return ht.loadAll(Clients.class);
	}

}
