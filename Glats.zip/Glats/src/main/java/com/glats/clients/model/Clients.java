package com.glats.clients.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Clients")
public class Clients {

	@Id
	@GeneratedValue
	public Integer clientId;
	@Column
	private String clientName;
	@Column
	private long mobileNumber;
	@Column
	private String emailId;
	@Column
	private String companyName;
	@Column
	private String website;
	@Column
	private String industry;
	@Column
	private String createdBy;
	@Column
	private String about;
	@Column
	private String pointOfContact;
	
	public Clients() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Clients(Integer clientId, String clientName, long mobileNumber, String emailId, String companyName,
			String website, String industry, String createdBy, String about, String pointOfContact) {
		super();
		this.clientId = clientId;
		this.clientName = clientName;
		this.mobileNumber = mobileNumber;
		this.emailId = emailId;
		this.companyName = companyName;
		this.website = website;
		this.industry = industry;
		this.createdBy = createdBy;
		this.about = about;
		this.pointOfContact = pointOfContact;
	}
	public Integer getClientId() {
		return clientId;
	}
	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	public String getPointOfContact() {
		return pointOfContact;
	}
	public void setPointOfContact(String pointOfContact) {
		this.pointOfContact = pointOfContact;
	}
	@Override
	public String toString() {
		return "Clients [clientId=" + clientId + ", clientName=" + clientName + ", mobileNumber=" + mobileNumber
				+ ", emailId=" + emailId + ", companyName=" + companyName + ", website=" + website + ", industry="
				+ industry + ", createdBy=" + createdBy + ", about=" + about + ", pointOfContact=" + pointOfContact
				+ "]";
	}	
}