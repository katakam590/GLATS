package com.glats.clients.service;

import java.util.List;

import com.glats.clients.model.Clients;

public interface ClientsService {
	public Integer saveClient(Clients clt) ;
	public void updateClient(Clients clt);
	public void deleteClient(Integer clientId);
	public List<Clients>getAllClients();
	public Clients getOneClientById(Integer clientId);
}
