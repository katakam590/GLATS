package com.glats.clients.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glats.clients.dao.ClientsDao;
import com.glats.clients.model.Clients;
import com.glats.clients.service.ClientsService;

@Service
public class ClientsServiceImpl implements ClientsService {


	@Autowired
	private ClientsDao dao;
	@Transactional
	public Integer saveClient(Clients clt) {
		// TODO Auto-generated method stub
		return dao.saveClient(clt);
	}

	@Transactional
	public void updateClient(Clients clt) {
		dao.updateClient(clt);		
	}

	@Transactional
	public void deleteClient(Integer clientId) {
		dao.deleteClient(clientId);		
	}

	@Transactional(readOnly=true)
	public Clients getOneClientById(Integer cltId) {
		// TODO Auto-generated method stub
		return dao.getOneClientById(cltId);
	}

	@Transactional(readOnly=true)
	public List<Clients> getAllClients() {
		// TODO Auto-generated method stub
		return dao.getAllClients();
	}
}
