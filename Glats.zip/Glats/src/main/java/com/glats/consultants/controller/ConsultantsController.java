package com.glats.consultants.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.glats.consultants.model.Consultants;
import com.glats.consultants.service.IConsultantsService;


@Controller
@RequestMapping("/consultants")
public class ConsultantsController {

	@Autowired
	private IConsultantsService service;

	@RequestMapping("/register")
	public String register(ModelMap map) {
		map.addAttribute("consultants", new Consultants());

		return "consultantsRegister";
	}

	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String insertConsultants(@ModelAttribute Consultants consultants) {

		Integer id= service.saveConsultants(consultants);
		System.out.println(id);

		return "consultantsRegister";
	}

	@RequestMapping("/all")
	public String showData(ModelMap map) {
		List<Consultants> cons=service.getAllConsultants();
		for(Consultants consultants : cons) {
			System.out.println(consultants);
		}

		map.addAttribute("consultants", cons);
		return "consultantsData";

	}

	@RequestMapping("/delete")
	public String deleteCons(@RequestParam("consultantsid") Integer consultantsid,ModelMap map) {
		service.deleteConsultants(consultantsid);
		//constract finall message

		String msg="Consultants"+consultantsid+"Deleted";

		//get new Data from database
		List<Consultants> cons=service.getAllConsultants();
		//send to ui
		map.addAttribute("message",msg);
		map.addAttribute("cons", cons);
		return "consultantsData";

	}

	// Edit operation
	@RequestMapping("/edit")
	public String showEdit(@RequestParam("consultantsid")Integer consultantsid,ModelMap map)
	{
		Consultants cons=service.getOneConsultantsById(consultantsid);
		map.addAttribute("cons", cons);
		return "consultantsEdit";
	}


	// do update Operation
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String doUpdateData(@ModelAttribute Consultants consultants,ModelMap map){
		service.updateConsultants(consultants); 
		String  msg="Consultants'"+consultants.consultantsId+"'updated";

		List<Consultants> cons=service.getAllConsultants(); 
        map.addAttribute("message",msg);
		map.addAttribute("consultants", cons);

		return "consultantsData"; 
	}
}
