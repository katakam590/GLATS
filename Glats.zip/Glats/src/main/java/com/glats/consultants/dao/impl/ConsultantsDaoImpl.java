package com.glats.consultants.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.glats.consultants.dao.IConsultantsDao;
import com.glats.consultants.model.Consultants;


@Repository
public class ConsultantsDaoImpl implements IConsultantsDao {

	@Autowired
	private HibernateTemplate ht;

	@Override
	public Integer saveConsultants(Consultants cons) {
		// TODO Auto-generated method stub
		return (Integer) ht.save(cons);
	}

	@Override
	public void updateConsultants(Consultants consultantsid) {
		// TODO Auto-generated method stub
		ht.update(consultantsid);
	}

	@Override
	public void deleteConsultants(Integer consultantsid) {
		// TODO Auto-generated method stub
		Consultants e=new Consultants();
		e.setConsultantsId(consultantsid);
		ht.delete(e);
	}

	@Override
	public Consultants getOneConsultantsById(Integer consId) {
		// TODO Auto-generated method stub
		return ht.get(Consultants.class, consId);
	}

	@Override
	public List<Consultants> getAllConsultants() {
		// TODO Auto-generated method stub
		return ht.loadAll(Consultants.class);
	}

}
