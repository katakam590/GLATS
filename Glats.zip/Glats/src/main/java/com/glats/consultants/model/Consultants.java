package com.glats.consultants.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Consultants")
public class Consultants {

	@Id
	@GeneratedValue
	public Integer consultantsId;
	@Column
	private String consultantName;
	@Column
	private String emailId;
	@Column
	private String	mobileNumber;
	@Column
	private String secondaryEmail;
	@Column
	private String	passportId;
	@Column
	private String	visa;
	@Column
	private String street;
	@Column
	private String city;
	@Column
	private String state;
	@Column
	private String	code;
	@Column
	private String country;	
	@Column
	private String	createdBy;
	@Column
	private String workExperience;
	@Column
	private String highestQualification;
	@Column
	private String currentJobTitle;
	@Column
	private String	currentSalary;
	@Column
	private String	expectedSalary;
	@Column
	private String	skills;
	@Column
	private String	additionalInfo;
	public Consultants() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Consultants(Integer consultantsId, String consultantName, String emailId, String mobileNumber,
			String secondaryEmail, String passportId, String visa, String street, String city, String state,
			String code, String country, String createdBy, String workExperience, String highestQualification,
			String currentJobTitle, String currentSalary, String expectedSalary, String skills, String additionalInfo) {
		super();
		this.consultantsId = consultantsId;
		this.consultantName = consultantName;
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
		this.secondaryEmail = secondaryEmail;
		this.passportId = passportId;
		this.visa = visa;
		this.street = street;
		this.city = city;
		this.state = state;
		this.code = code;
		this.country = country;
		this.createdBy = createdBy;
		this.workExperience = workExperience;
		this.highestQualification = highestQualification;
		this.currentJobTitle = currentJobTitle;
		this.currentSalary = currentSalary;
		this.expectedSalary = expectedSalary;
		this.skills = skills;
		this.additionalInfo = additionalInfo;
	}
	public Integer getConsultantsId() {
		return consultantsId;
	}
	public void setConsultantsId(Integer consultantsId) {
		this.consultantsId = consultantsId;
	}
	public String getConsultantName() {
		return consultantName;
	}
	public void setConsultantName(String consultantName) {
		this.consultantName = consultantName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getSecondaryEmail() {
		return secondaryEmail;
	}
	public void setSecondaryEmail(String secondaryEmail) {
		this.secondaryEmail = secondaryEmail;
	}
	public String getPassportId() {
		return passportId;
	}
	public void setPassportId(String passportId) {
		this.passportId = passportId;
	}
	public String getVisa() {
		return visa;
	}
	public void setVisa(String visa) {
		this.visa = visa;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getWorkExperience() {
		return workExperience;
	}
	public void setWorkExperience(String workExperience) {
		this.workExperience = workExperience;
	}
	public String getHighestQualification() {
		return highestQualification;
	}
	public void setHighestQualification(String highestQualification) {
		this.highestQualification = highestQualification;
	}
	public String getCurrentJobTitle() {
		return currentJobTitle;
	}
	public void setCurrentJobTitle(String currentJobTitle) {
		this.currentJobTitle = currentJobTitle;
	}
	public String getCurrentSalary() {
		return currentSalary;
	}
	public void setCurrentSalary(String currentSalary) {
		this.currentSalary = currentSalary;
	}
	public String getExpectedSalary() {
		return expectedSalary;
	}
	public void setExpectedSalary(String expectedSalary) {
		this.expectedSalary = expectedSalary;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getAdditionalInfo() {
		return additionalInfo;
	}
	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	@Override
	public String toString() {
		return "Consultants [consultantsId=" + consultantsId + ", consultantName=" + consultantName + ", emailId="
				+ emailId + ", mobileNumber=" + mobileNumber + ", secondaryEmail=" + secondaryEmail + ", passportId="
				+ passportId + ", visa=" + visa + ", street=" + street + ", city=" + city + ", state=" + state
				+ ", code=" + code + ", country=" + country + ", createdBy=" + createdBy + ", workExperience="
				+ workExperience + ", highestQualification=" + highestQualification + ", currentJobTitle="
				+ currentJobTitle + ", currentSalary=" + currentSalary + ", expectedSalary=" + expectedSalary
				+ ", skills=" + skills + ", additionalInfo=" + additionalInfo + "]";
	}
}