package com.glats.consultants.service;

import java.util.List;

import com.glats.consultants.model.Consultants;



public interface IConsultantsService {
	public Integer saveConsultants(Consultants cons) ;
	public void updateConsultants(Consultants cons);
	public void deleteConsultants(Integer consId);
	public Consultants getOneConsultantsById(Integer consId);
	public List<Consultants> getAllConsultants();
}
