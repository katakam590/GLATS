package com.glats.consultants.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glats.consultants.dao.IConsultantsDao;
import com.glats.consultants.model.Consultants;
import com.glats.consultants.service.IConsultantsService;

@Service
public class EmployeeServiceImpl implements IConsultantsService {


	@Autowired
	private IConsultantsDao dao;
	@Transactional
	public Integer saveConsultants(Consultants cons) {
		// TODO Auto-generated method stub
		return dao.saveConsultants(cons);
	}

	@Transactional
	public void updateConsultants(Consultants cons) {
		dao.updateConsultants(cons);		
	}

	@Transactional
	public void deleteConsultants(Integer consultantsid) {
		dao.deleteConsultants(consultantsid);		
	}

	@Transactional(readOnly=true)
	public Consultants getOneConsultantsById(Integer consultantsid) {
		// TODO Auto-generated method stub
		return dao.getOneConsultantsById(consultantsid);
	}

	@Transactional(readOnly=true)
	public List<Consultants> getAllConsultants() {
		// TODO Auto-generated method stub
		return dao.getAllConsultants();
	}


}
