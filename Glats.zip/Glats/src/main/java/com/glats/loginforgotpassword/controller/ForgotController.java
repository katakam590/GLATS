package com.glats.loginforgotpassword.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.glats.loginforgotpassword.email.MailServiceForgot;
import com.glats.loginforgotpassword.model.Forgot;
import com.glats.loginforgotpassword.model.User;
import com.glats.loginforgotpassword.service.UserService;

@Controller
public class ForgotController {
	@Autowired
	private UserService service;
	@Autowired
	private MailServiceForgot mailServiceForgot;

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.GET)
	public String forgotPassword(ModelMap map) {
		map.addAttribute("forgot", new Forgot());
		System.out.println("insid forgotpassword() of controller class");
		return "forgotPassword";
	}

	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
	public String resetRequest(@RequestParam(value = "email") String email) {
		// check if the email id is valid and registered with us.
		mailServiceForgot.sendMail(email);
		System.out.println("restrequest(_) of controller class");
		return "checkMail1";
	}

	@RequestMapping(value = "/newPassword/{email}")
	public String resetPassword(@PathVariable String email, Map<String, String> model) {
		// check if the email id is valid and registered with us.
		model.put("emailid", email);
		return "newPassword";
	}

	@RequestMapping(value = "/newPassword/{email}/save", method = RequestMethod.POST)
	public String savePassword(@ModelAttribute Forgot forgot, @PathVariable String email) {
		System.out.println(email + "   " + forgot);

		service.saveForgot(forgot);
		/*
		 * if (userId.equals(user.getUserId())) { System.out.println("get user id:" +
		 * user.getUserId()); }
		 */
		return "save";
	}
}
