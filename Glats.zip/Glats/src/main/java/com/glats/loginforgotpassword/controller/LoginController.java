package com.glats.loginforgotpassword.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.glats.loginforgotpassword.email.MailService;
import com.glats.loginforgotpassword.model.User;
import com.glats.loginforgotpassword.service.UserService;

@Controller
@RequestMapping("/login")
public class LoginController {

	@Autowired
	private UserService service;

	/*
	 * @Autowired private MailService mailService;
	 */

	@RequestMapping("/apply")
	public String register(ModelMap map) {
		map.addAttribute("user", new User());

		return "apply";
	}

	@RequestMapping(value = "/feed", method = RequestMethod.POST)
	public String insertProfile(@ModelAttribute User user) {

		Integer userId = service.saveUser(user);

		System.out.println("save id:" + userId);

		if (userId.equals(user.getUserId())) {
			System.out.println("get user id:" + user.getUserId());
			// here to Send mail to the Email
			// check if the email id is valid and registered with us.
			// mailService.sendMail(user.getEmail()); return "checkMail";
		}

		return "apply";
	}

	@RequestMapping("/cancel")
	public String Cancel(ModelMap map) {
		map.addAttribute("login", new User());

		return "register";
	}

	// this one fetching data

	@RequestMapping("/info")
	public String showData(ModelMap map) {
		List<User> login = service.getAllUser();
		for (User login2 : login) {
			System.out.println(login2);
		}

		map.addAttribute("login", login);

		return "ProfileData";

	}

	@RequestMapping("/delete")
	public String deleteLogin(@RequestParam("userId") Integer userId, ModelMap map) {
		service.deleteUser(userId);
		// constract finall message

		// String msg = "User" + userId + "Deleted";

		// get new Data from database
		List<User> login = service.getAllUser();
		// send to ui
		// map.addAttribute("message", msg);
		map.addAttribute("login", login);

		return "ProfileData";

	}

	// Edit operation

	@RequestMapping("/edit")
	public String showEdit(@RequestParam("userId") Integer userId, ModelMap map) {
		User login = service.getOneUserByEmail(userId);
		map.addAttribute("login", login);
		return "ProfileEdit";
	}

	// do update Operation

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String doUpdateData(@ModelAttribute User login, ModelMap map) {
		service.updateUser(login);
		String msg = "login" + login.getUserId() + "'updated";

		List<User> login1 = service.getAllUser();
		map.addAttribute("message", msg);
		map.addAttribute("login", login1);

		return "ProfileData";
	}
}
