package com.glats.loginforgotpassword.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.glats.loginforgotpassword.email.MailService;
import com.glats.loginforgotpassword.model.User;
import com.glats.loginforgotpassword.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private MailService mailService; 

	@RequestMapping("/register")
	public String register(ModelMap map) {
		map.addAttribute("user", new User());

		return "register";
	}

	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public String insertUser(@ModelAttribute User user) {


		Integer userId = service.saveUser(user);
		System.out.println("save userId:"+userId);

		if (userId.equals(user.getUserId())) {
			System.out.println("get user Id:"+user.getUserId());
			// here to Send mail  to the gmail
			// check if the email id is valid and registered with us.
			mailService.sendMail(user.getEmail());
			return "checkMail";
		}

		return "register";
	}

	@RequestMapping("/cancel")
	public String Cancel(ModelMap map) {
		map.addAttribute("user", new User());

		return "register";
	}

	@RequestMapping("/all")
	public String showData(ModelMap map) {
		List<User> usr = service.getAllUser();

		map.addAttribute("user", usr);
		return "UserData";

	}

	@RequestMapping("/delete")
	public String deleteusr(@RequestParam("userId") Integer userId, ModelMap map) {
		service.deleteUser(userId);
		// constract finall message

		//		String msg = "User" + userId + "Deleted";

		// get new Data from database
		List<User> usr = service.getAllUser();
		// send to ui
		//		map.addAttribute("message", msg);
		map.addAttribute("usr", usr);

		return "UserData";

	}

	// Edit operation

	@RequestMapping("/edit")
	public String showEdit(@RequestParam("userId") Integer userId, ModelMap map) {
		User usr = service.getOneUserByEmail(userId);
		map.addAttribute("user", usr);
		return "UserEdit";
	}

	// do update Operation

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String doUpdateData(@ModelAttribute User user, ModelMap map) {
		service.updateUser(user);
		String msg = "user" + user.getEmail() + "'updated";

		List<User> users = service.getAllUser();
		map.addAttribute("message", msg);
		map.addAttribute("user", users);

		return "UserData";
	}

}