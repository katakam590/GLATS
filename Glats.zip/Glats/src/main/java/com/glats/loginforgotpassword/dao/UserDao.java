package com.glats.loginforgotpassword.dao;

import java.util.List;

import com.glats.loginforgotpassword.model.Forgot;
import com.glats.loginforgotpassword.model.User;

public interface UserDao {
   public Integer saveUser(User user) ;
   public void updateUser(User user);
   public void deleteUser(Integer userId);
   public User getOneUserByEmail(Integer userId);
   public List<User>getAllUser(); 
   public void saveForgot(Forgot forgot);
   
}
