package com.glats.loginforgotpassword.dao.impl;

import java.util.List;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.glats.loginforgotpassword.dao.UserDao;
import com.glats.loginforgotpassword.model.Forgot;
import com.glats.loginforgotpassword.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private HibernateTemplate ht;

	public Integer saveUser(User user) {
		return (Integer) ht.save(user);
	}

	public void updateUser(User user) {
		ht.update(user);
	}

	public void deleteUser(Integer userId) {
		User user = new User();
		user.setUserId(userId);
		ht.delete(user);
		ht.flush();

	}

	public User getOneUserByEmail(Integer userId) {
		return ht.get(User.class, userId);
	}

	public List<User> getAllUser() {

		return ht.loadAll(User.class);

	}

	@Override
	public void saveForgot(Forgot forgot) {
		System.out.println("inside userdaoimpl's saveforgotmethod");
		System.out.println(forgot);
		ht.saveOrUpdate(forgot);
	}
}
