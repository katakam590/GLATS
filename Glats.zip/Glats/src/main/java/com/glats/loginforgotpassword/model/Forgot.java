package com.glats.loginforgotpassword.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Forgot")
public class Forgot {

	@Id
	@SequenceGenerator(name = "seqToken", sequenceName = "SEQ_TOKEN", initialValue = 100, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqToken")
	@Column(name = "forgotId")
	private Integer forgotId;
	@Column(name = "newpassword")
	private String newpassword;
	@Column(name = "retypepassword")
	private String retypepassword;

	public Forgot() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Forgot(Integer forgotId, String newpassword, String retypepassword) {
		super();
		this.forgotId = forgotId;
		this.newpassword = newpassword;
		this.retypepassword = retypepassword;
	}

	public Integer getForgotId() {
		return forgotId;
	}

	public void setForgotId(Integer forgotId) {
		this.forgotId = forgotId;
	}

	public String getNewpassword() {
		return newpassword;
	}

	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}

	public String getRetypepassword() {
		return retypepassword;
	}

	public void setRetypepassword(String retypepassword) {
		this.retypepassword = retypepassword;
	}

	@Override
	public String toString() {
		return "Forgot [forgotId=" + forgotId + ", newpassword=" + newpassword + ", retypepassword=" + retypepassword
				+ "]";
	}
}
