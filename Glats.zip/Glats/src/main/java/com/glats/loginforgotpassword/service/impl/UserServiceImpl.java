package com.glats.loginforgotpassword.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glats.loginforgotpassword.dao.UserDao;
import com.glats.loginforgotpassword.model.Forgot;
import com.glats.loginforgotpassword.model.User;
import com.glats.loginforgotpassword.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao dao;

	@Transactional
	public Integer saveUser(User user) {
		return dao.saveUser(user);
	}

	@Transactional
	public void updateUser(User user) {
		dao.updateUser(user);
	}

	@Transactional
	public void deleteUser(Integer userId) {
		dao.deleteUser(userId);
	}

	@Transactional(readOnly = true)
	public User getOneUserByEmail(Integer userId) {
		return dao.getOneUserByEmail(userId);
	}

	@Transactional(readOnly = true)
	public List<User> getAllUser() {
		return dao.getAllUser();
	}

	@Transactional
	public void saveForgot(Forgot forgot) {
		System.out.println("inside saveforgot of UserserviceImpl...");
		System.out.println(forgot);
		dao.saveForgot(forgot);
		System.out.println("after save operation");
	}
}
