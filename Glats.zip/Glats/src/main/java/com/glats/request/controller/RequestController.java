package com.glats.request.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.glats.request.email.MailServiceRequest;
import com.glats.request.model.RequestForDemo;
import com.glats.request.service.IRequestForDemo;

@Controller
public class RequestController {
	@Autowired
	public IRequestForDemo service;
	@Autowired
	private MailServiceRequest mailServiceRequest; 
	
	@RequestMapping("/RequestForDemo")
	public String Request(ModelMap map)
	{
	map.addAttribute("Request", new RequestForDemo());
	return "RequestForDemo";
	}

	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String Request(@ModelAttribute RequestForDemo request,@RequestParam(value="email")String email) {
		Integer id= service.saveRequest(request);
		 System.out.println(id); 
		 mailServiceRequest.sendMail(email);
		return "success";
		
	}
}
	
