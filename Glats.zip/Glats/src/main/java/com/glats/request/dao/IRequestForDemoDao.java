package com.glats.request.dao;

import com.glats.request.model.RequestForDemo;

public interface IRequestForDemoDao {
	public Integer saveRequest(RequestForDemo request);
}
