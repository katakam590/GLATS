package com.glats.request.service;

import com.glats.request.model.RequestForDemo;

public interface IRequestForDemo {
	
	public Integer saveRequest(RequestForDemo request);

}
