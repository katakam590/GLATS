package com.glats.request.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glats.request.dao.IRequestForDemoDao;
import com.glats.request.model.RequestForDemo;
import com.glats.request.service.IRequestForDemo;

@Service
public class RequestForDemoServiceImpl implements IRequestForDemo {

	
	@Autowired
	private IRequestForDemoDao dao;
	@Transactional
	public Integer saveRequest(RequestForDemo request) {
		// TODO Auto-generated method stub
		return dao.saveRequest(request);
	}

}
