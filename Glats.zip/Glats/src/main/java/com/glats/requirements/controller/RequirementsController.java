package com.glats.requirements.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.glats.requirements.model.Requirements;
import com.glats.requirements.service.IEmployeeService;

@Controller
@RequestMapping("/requirements")
public class RequirementsController {

	@Autowired
	private IEmployeeService service;

	@RequestMapping("/register")
	public String register(ModelMap map) {
		map.addAttribute("employee", new Requirements());

		return "requirementsRegister";
	}
	@RequestMapping("/requirement-create")
	public String requirement(ModelMap map) {
		map.addAttribute("employee", new Requirements());

		return "requirement-create";
	}

	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String insertEmployee(@ModelAttribute Requirements employee) {

		Integer id= service.saveJobPosting(employee);
		System.out.println(id);

		return "requirementsRegister";
	}

	@RequestMapping("/all")
	public String showData(ModelMap map) {
		List<Requirements> emps=service.getAllEmployee();
		for (Requirements employee : emps) {
			System.out.println(employee);
		}

		map.addAttribute("employee", emps);
		return "requirementsData";

	}

	@RequestMapping("/delete")
	public String deleteEmp(@RequestParam("requirementId") Integer requirementId,ModelMap map) {
		service.deleteJobPosting(requirementId);
		//constract finall message

		String msg="Employee"  +requirementId+ "Deleted";

		//get new Data from database
		List<Requirements> emps=service.getAllEmployee();
		//send to ui
		map.addAttribute("message",msg);
		map.addAttribute("emps", emps);
		return "requirementsData";

	}

	// Edit operation
	@RequestMapping("/edit")
	public String showEdit(@RequestParam("postingid")Integer postingid,ModelMap map)
	{
		Requirements emp=service.getOneEmployeeById(postingid);
		map.addAttribute("employee", emp);
		return "requirementsEdit";
	}


	// do update Opration
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String doUpdateData(@ModelAttribute Requirements employee,ModelMap map){
		service.updateJobPosting(employee); 
		String  msg="Employee"+ employee.requirementId +"updated";

		List<Requirements> emps=service.getAllEmployee(); 
        map.addAttribute("message",msg);
		map.addAttribute("employee", emps);

		return "requirementsData"; 
	}

}
