package com.glats.requirements.dao;

import java.util.List;

import com.glats.requirements.model.Requirements;

public interface IEmployeeDao {
   public Integer saveJobPosting(Requirements emp) ;
   public void updateJobPosting(Requirements emp);
   public void deleteJobPosting(Integer empId);
   public Requirements getOneEmployeeById(Integer empId);
   public List<Requirements> getAllEmployee();
}
