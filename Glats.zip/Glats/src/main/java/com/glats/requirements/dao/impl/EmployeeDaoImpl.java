package com.glats.requirements.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.glats.requirements.dao.IEmployeeDao;
import com.glats.requirements.model.Requirements;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao {

	@Autowired
	private HibernateTemplate ht;

	@Override
	public Integer saveJobPosting(Requirements emp) {
		// TODO Auto-generated method stub
		return (Integer) ht.save(emp);
	}

	@Override
	public void updateJobPosting(Requirements postingid) {
		// TODO Auto-generated method stub
		ht.update(postingid);
	}

	@Override
	public void deleteJobPosting(Integer requirementId) {
		// TODO Auto-generated method stub
		Requirements e=new Requirements();
		e.setRequirementId(requirementId);
		ht.delete(e);
	}

	@Override
	public Requirements getOneEmployeeById(Integer empId) {
		// TODO Auto-generated method stub
		return ht.get(Requirements.class, empId);
	}

	@Override
	public List<Requirements> getAllEmployee() {
		// TODO Auto-generated method stub
		return ht.loadAll(Requirements.class);
	}

}
