package com.glats.requirements.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Vishnu Kumar Reddy
 *
 */
@Entity
@Table(name = "Requirements")
public class Requirements {

	@Id
	@GeneratedValue
	public Integer requirementId;
	@Column
	private String date;
	@Column
	private String postingTitle;
	@Column
	private String clientName;
	@Column
	private String assignedTo;
	@Column
	private String accountManager;
	@Column
	private String clientRate;
	@Column
	private String payRate;
	@Column
	private String jobType;
	@Column
	private String city;
	@Column
	private String industry;
	@Column
	private String state;
	@Column
	private String code;
	@Column
	private String workExperience;
	@Column
	private String country;
	@Column
	private String visa;
	@Column
	private String visaType;
	@Column
	private String salary;
	@Column
	private String openings;
	@Column
	private String createdBy;
	
	public Requirements() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Requirements(Integer requirementId, String date, String postingTitle, String clientName, String assignedTo,
			String accountManager, String clientRate, String payRate, String jobType, String city, String industry,
			String state, String code, String workExperience, String country, String visa, String visaType,
			String salary, String openings, String createdBy) {
		super();
		this.requirementId = requirementId;
		this.date = date;
		this.postingTitle = postingTitle;
		this.clientName = clientName;
		this.assignedTo = assignedTo;
		this.accountManager = accountManager;
		this.clientRate = clientRate;
		this.payRate = payRate;
		this.jobType = jobType;
		this.city = city;
		this.industry = industry;
		this.state = state;
		this.code = code;
		this.workExperience = workExperience;
		this.country = country;
		this.visa = visa;
		this.visaType = visaType;
		this.salary = salary;
		this.openings = openings;
		this.createdBy = createdBy;
	}
	public Integer getRequirementId() {
		return requirementId;
	}
	public void setRequirementId(Integer requirementId) {
		this.requirementId = requirementId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getPostingTitle() {
		return postingTitle;
	}
	public void setPostingTitle(String postingTitle) {
		this.postingTitle = postingTitle;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getAccountManager() {
		return accountManager;
	}
	public void setAccountManager(String accountManager) {
		this.accountManager = accountManager;
	}
	public String getClientRate() {
		return clientRate;
	}
	public void setClientRate(String clientRate) {
		this.clientRate = clientRate;
	}
	public String getPayRate() {
		return payRate;
	}
	public void setPayRate(String payRate) {
		this.payRate = payRate;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getWorkExperience() {
		return workExperience;
	}
	public void setWorkExperience(String workExperience) {
		this.workExperience = workExperience;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getVisa() {
		return visa;
	}
	public void setVisa(String visa) {
		this.visa = visa;
	}
	public String getVisaType() {
		return visaType;
	}
	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getOpenings() {
		return openings;
	}
	public void setOpenings(String openings) {
		this.openings = openings;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	@Override
	public String toString() {
		return "Requirements [requirementId=" + requirementId + ", date=" + date + ", postingTitle=" + postingTitle
				+ ", clientName=" + clientName + ", assignedTo=" + assignedTo + ", accountManager=" + accountManager
				+ ", clientRate=" + clientRate + ", payRate=" + payRate + ", jobType=" + jobType + ", city=" + city
				+ ", industry=" + industry + ", state=" + state + ", code=" + code + ", workExperience="
				+ workExperience + ", country=" + country + ", visa=" + visa + ", visaType=" + visaType + ", salary="
				+ salary + ", openings=" + openings + ", createdBy=" + createdBy + "]";
	}
}
