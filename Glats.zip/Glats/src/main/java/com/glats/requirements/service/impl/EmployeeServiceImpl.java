package com.glats.requirements.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glats.requirements.dao.IEmployeeDao;
import com.glats.requirements.model.Requirements;
import com.glats.requirements.service.IEmployeeService;

@Service
public class EmployeeServiceImpl implements IEmployeeService {


	@Autowired
	private IEmployeeDao dao;
	@Transactional
	public Integer saveJobPosting(Requirements emp) {
		// TODO Auto-generated method stub
		return dao.saveJobPosting(emp);
	}

	@Transactional
	public void updateJobPosting(Requirements emp) {
		dao.updateJobPosting(emp);		
	}

	@Transactional
	public void deleteJobPosting(Integer postingid) {
		dao.deleteJobPosting(postingid);		
	}

	@Transactional(readOnly=true)
	public Requirements getOneEmployeeById(Integer empId) {
		// TODO Auto-generated method stub
		return dao.getOneEmployeeById(empId);
	}

	@Transactional(readOnly=true)
	public List<Requirements> getAllEmployee() {
		// TODO Auto-generated method stub
		return dao.getAllEmployee();
	}


}
