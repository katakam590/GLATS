package com.glats.search.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.glats.search.model.Employee;
import com.glats.search.service.IEmployeeService;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private IEmployeeService service;

	// show page method
	@RequestMapping("/register")
	public String showRegPage(ModelMap map) {
		map.addAttribute("employee", new Employee());
		return "EmployeeRegister";
	}

	// insert method
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public String saveData(@ModelAttribute Employee employee, ModelMap map) {
		Integer empId = service.saveEmployee(employee);
		String msg = "Item'" + empId + "'saved";
		map.addAttribute("message", msg);
		map.addAttribute("employee", new Employee());
		return "EmployeeRegister";
	}

	@RequestMapping("/all")
	public String showData(ModelMap map) {

		List<Employee> emps = service.getAllItem();

		map.addAttribute("emps", emps);
		return "EmployeeData";

	}

	// search method
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String SearchData(@RequestParam("search") String search, ModelMap map) {
		List<Employee> emps = service.getSearchEmployeeData(search);
		map.addAttribute("emps", emps);

		return "EmployeeData";
	}

	/*
	 * //delete operation
	 * 
	 * @RequestMapping("/delete") public String deleteItem(@RequestParam("id")
	 * Integer itemId,ModelMap map) { service.deteleItem(itemId); //constract finall
	 * message
	 * 
	 * String msg="Item"+itemId+"Deleted";
	 * 
	 * //get new Data from database List<Item> items=service.getAllItem(); //send to
	 * ui map.addAttribute("message",msg);
	 * 
	 * List<UnitOfMesurment> unitOfMesurment=unitService.getAllUnitOfMesurment();
	 * map.addAttribute("uom", unitOfMesurment);
	 * 
	 * 
	 * map.addAttribute("items", items); return "ItemData";
	 * 
	 * } // Edit operation
	 * 
	 * @RequestMapping("/edit") public String showEdit(@RequestParam("id")int
	 * itemId,ModelMap map) { Item items=service.getOneItemById(itemId);
	 * 
	 * 
	 * //get all unitOfMesurment List<UnitOfMesurment>
	 * unitOfMesurment=unitService.getAllUnitOfMesurment(); map.addAttribute("uoms",
	 * unitOfMesurment);
	 * 
	 * //get sales data only List<OrderMethod>
	 * sales=orderMethodService.getOrderMethodByMode("sale");
	 * map.addAttribute("sales", sales);
	 * 
	 * //get sales purchase only List<OrderMethod>
	 * purchases=orderMethodService.getOrderMethodByMode("purchase");
	 * map.addAttribute("purchases", purchases);
	 * 
	 * 
	 * List<WhUserType> vendor=whUserTypeService.getOneWhUserByType("VENDER");
	 * map.addAttribute("vendor", vendor); List<WhUserType> customer
	 * =whUserTypeService.getOneWhUserByType("CUSTOMER");
	 * map.addAttribute("customer", customer);
	 * 
	 * map.addAttribute("item", items); return "ItemEdit"; }
	 * 
	 * 
	 * // update Operation
	 * 
	 * @RequestMapping(value="/update",method=RequestMethod.POST) public String
	 * doUpdateData(@ModelAttribute Item item,ModelMap map){
	 * service.updateItem(item); String msg="item'"+item.getItemId()+"'updated";
	 * 
	 * List<UnitOfMesurment> unitOfMesurment=unitService.getAllUnitOfMesurment();
	 * map.addAttribute("uoms", unitOfMesurment);
	 * 
	 * 
	 * List<Item> items=service.getAllItem(); map.addAttribute("message", msg);
	 * map.addAttribute("items", items); return "ItemData";
	 * 
	 * 
	 * }
	 */

}
