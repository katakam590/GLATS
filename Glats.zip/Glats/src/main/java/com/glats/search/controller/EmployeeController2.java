package com.glats.search.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.glats.search.model.Employee;
import com.glats.search.service.IEmployeeService;

@Controller
public class EmployeeController2 {

	@Autowired
	private IEmployeeService service;

	@GetMapping("register2")
	public String ok(ModelMap map) {
		map.addAttribute("employee", new Employee());
		return "EmployeeRegister";
	}
}
