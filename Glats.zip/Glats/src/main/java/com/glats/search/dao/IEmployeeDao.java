package com.glats.search.dao;

import java.util.List;

import com.glats.search.model.Employee;

public interface IEmployeeDao {

	public Integer saveEmployee(Employee employee);
	public void updateEmployee(Employee employee);
	public void detelEmployee(Integer employeeId);
	public Employee getOneItemById(Integer employeeId);
	public List<Employee> getAllItem();
	public List<Employee> getSearchEmployeeData(String Search);
}
