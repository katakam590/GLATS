package com.glats.search.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.glats.search.dao.IEmployeeDao;
import com.glats.search.model.Employee;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao {
	@Autowired
	private HibernateTemplate ht;
	private Object session;

	@Override
	public Integer saveEmployee(Employee employee) {

		System.out.println("----------------------------------" + employee.getEmpMail() + " "
				+ employee.getEmpMobileNumber() + " " + employee.getEmpSalary());

		return (Integer) ht.save(employee);
	}

	@Override
	public void updateEmployee(Employee employee) {
		ht.update(employee);
	}

	@Override
	public void detelEmployee(Integer employeeId) {
		Employee e = new Employee();
		e.setEmpId(employeeId);
		ht.delete(e);

	}

	@Override
	public Employee getOneItemById(Integer employeeId) {
		return ht.get(Employee.class, employeeId);
	}

	@Override
	public List<Employee> getAllItem() {
		return ht.loadAll(Employee.class);
	}

	@Override
	public List<Employee> getSearchEmployeeData(String search) {

		// String hql = "from employee e where e.name like '%:name%'";
		/*
		 * Query query = session.createQuery(hql); query.setParameter("employee_id",10);
		 * List results = query.list();
		 */

		// Employee emp = (Employee) ht.findByNamedParam(hql, "name", search);

		String query = " from " + Employee.class.getName() + " where empName like concat('%',?,'%')";

		@SuppressWarnings({ "deprecation", "unchecked" })
		List<Employee> list = (List<Employee>) ht.find(query, search);

		/*
		 * @SuppressWarnings("deprecation") Employee
		 * emp=(Employee)ht.findByNamedParam(quary, paramNames, values)
		 */
		// Employee e=new Employee();
		// e.setEmpName(search);
		// System.out.println("======================"+e.getEmpName());
		// String hql = " from "+Employee.class.getName()+" where empName=?"; //this one
		// String hql=" from"+Employee.class.getName()+" where empName like %=?%";
		// List<Employee> list = (List<Employee>)ht.find(hql,search);

		/*
		 * String hql=" from "+WhUserType.class.getName()+" where type=?";
		 * List<WhUserType> list = (List<WhUserType>) ht.find(hql, userType); return
		 * list;
		 */

		/*
		 * Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		 * session.beginTransaction(); List<User> result = (List<User>)
		 * session.createQuery("from users").list(); session.getTransaction().commit();
		 */
		return list;
	}

}
