package com.glats.search.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Employee")
public class Employee {
	@Id
	@GeneratedValue(generator = "employeeGen")
	@GenericGenerator(name = "employeeGen", strategy = "increment")
	@Column(name = "id")
	private Integer empId;

	@Column(name = "name")
	private String empName;

	@Column(name = "salary")
	private double empSalary;

	@Column(name = "number")
	private String empMobileNumber;

	@Column(name = "mail")
	private String empMail;

	public Employee() {
		super();
	}

	public Employee(Integer empId) {
		super();
		this.empId = empId;
	}

	public Employee(Integer empId, String empName, double empSalary, String empMobileNumber, String empMail) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empMobileNumber = empMobileNumber;
		this.empMail = empMail;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public String getEmpMobileNumber() {
		return empMobileNumber;
	}

	public void setEmpMobileNumber(String empMobileNumber) {
		this.empMobileNumber = empMobileNumber;
	}

	public String getEmpMail() {
		return empMail;
	}

	public void setEmpMail(String empMail) {
		this.empMail = empMail;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empMobileNumber="
				+ empMobileNumber + ", empMail=" + empMail + "]";
	}
}