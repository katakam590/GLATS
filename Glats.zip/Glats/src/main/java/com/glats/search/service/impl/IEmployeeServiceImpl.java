package com.glats.search.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glats.search.dao.IEmployeeDao;
import com.glats.search.model.Employee;
import com.glats.search.service.IEmployeeService;

@Service
public class IEmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IEmployeeDao dao;

	@Transactional
	public Integer saveEmployee(Employee employee) {

		return dao.saveEmployee(employee);
	}

	@Transactional
	public void updateEmployee(Employee employee) {
		dao.updateEmployee(employee);
	}

	@Transactional
	public void detelEmployee(Integer employeeId) {
		dao.detelEmployee(employeeId);

	}

	@Transactional(readOnly = true)
	public Employee getOneItemById(Integer employeeId) {
		return dao.getOneItemById(employeeId);
	}

	@Transactional(readOnly = true)
	public List<Employee> getAllItem() {
		return dao.getAllItem();
	}

	@Transactional(readOnly = true)
	public List<Employee> getSearchEmployeeData(String search) {
		return dao.getSearchEmployeeData(search);
	}

	/*
	 * @Autowired private IItemDao dao;
	 * 
	 * @Transactional public Integer saveItem(Item item) { return
	 * dao.saveItem(item);vgh }
	 * 
	 * @Transactional public void updateItem(Item item) { dao.updateItem(item); }
	 * 
	 * @Transactional public void deteleItem(Integer itemId) {
	 * dao.deteleItem(itemId); }
	 * 
	 * @Transactional(readOnly=true) public Item getOneItemById(Integer itemId) {
	 * return dao.getOneItemById(itemId); }
	 * 
	 * @Transactional(readOnly=true) public List<Item> getAllItem() { List<Item>
	 * item= dao.getAllItem();
	 * Collections.sort(item,(o1,o2)->o2.getItemId()-o1.getItemId()); return item; }
	 */

}
