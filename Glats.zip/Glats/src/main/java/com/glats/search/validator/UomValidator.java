package com.glats.search.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class UomValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		
	}

	/*@Override
	public boolean supports(Class<?> clazz) {
		return UnitOfMesurment.class.equals(clazz);
	}

	@Overrides
	public void validate(Object target, Errors errors) {
		UnitOfMesurment uom=(UnitOfMesurment)target;

		if("".equals(uom.getType())) {
			errors.rejectValue("type", null, "Please choose one Type");
		}
		if("".equals(uom.getModel().trim())) {
			errors.rejectValue("model", null, "Please Enter Model");
		}
		if("".equals(uom.getDsc().trim())) {
			errors.rejectValue("dsc", null, "Please enter Description");
		}
	}

	}*/
}


