package com.glats.setting.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.glats.setting.model.Profile;
import com.glats.setting.service.IProfileService;




@Controller
@RequestMapping("/profile")
public class ProfileController {

	@Autowired
	private IProfileService service;

	//@Autowired
	//private MailService mailService; 

	@RequestMapping("/apply")
	public String register(ModelMap map) {
		map.addAttribute("profile", new Profile());

		return "apply";
	}


	@RequestMapping(value = "/feed", method = RequestMethod.POST) 
	public String insertProfile(@ModelAttribute Profile profile) {


		Integer id = service.saveProfile(profile);

		System.out.println("save id:"+id);

		if (id.equals(profile.getProfileId()))
		{
			System.out.println("get profile id:"+profile.getProfileId());
			// here to Send mail to the  Email
			// check if the email id is valid and registered with us.
			//mailService.sendMail(user.getEmail()); return "checkMail";
		}

		return "apply"; 
	}


	@RequestMapping("/cancel") 
	public String Cancel(ModelMap map)
	{
		map.addAttribute("profile", new Profile());

		return "register"; 
	}

	//this one fetching data

	@RequestMapping("/info") 
	public String showData(ModelMap map)
	{
		List<Profile> profile= service.getAllProfile();
		for (Profile profile2 : profile) {
               System.out.println(profile2);
		}

		map.addAttribute("profile", profile); 

		return "ProfileData";

	}

	@RequestMapping("/delete")
	public String deleteprofile(@RequestParam("profileId") Integer profileId, ModelMap map) {
		service.deleteProfile(profileId);
		// constract finall message

		//		String msg = "User" + userId + "Deleted";

		// get new Data from database
		List<Profile> profile = service.getAllProfile();
		// send to ui
		//		map.addAttribute("message", msg);
		map.addAttribute("profile", profile);

		return "ProfileData";

	}

	// Edit operation

	@RequestMapping("/edit")
	public String showEdit(@RequestParam("profileId") Integer profileId, ModelMap map) {
		Profile profile = service.getOneProfileById(profileId);
		map.addAttribute("profile", profile);
		return "ProfileEdit";
	}

	// do update Operation

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String doUpdateData(@ModelAttribute Profile profile, ModelMap map) {
		service.updateProfile(profile);
		String msg = "profile" + profile.getProfileId() + "'updated";

		List<Profile> profile1 = service.getAllProfile();
		map.addAttribute("message", msg);
		map.addAttribute("profile", profile1);

		return "ProfileData";
	}
}
