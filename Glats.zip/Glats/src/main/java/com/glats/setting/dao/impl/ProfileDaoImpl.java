package com.glats.setting.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.glats.setting.dao.IProfileDao;
import com.glats.setting.model.Profile;

@Repository
public class ProfileDaoImpl implements IProfileDao {

	@Autowired
	private HibernateTemplate ht;

	public Integer saveProfile(Profile Profile) {
		return (Integer) ht.save(Profile);
	}

	public void updateProfile(Profile profile) {
		ht.update(profile);
	}

	public void deleteProfile(Integer profileId) {
		Profile profile = new Profile();
		profile.setProfileId(profileId);
		ht.delete(profile);
		ht.flush();

	}

	public Profile getOneProfileById(Integer profileId) {
		return ht.get(Profile.class, profileId);
	}

	@Override
	public List<Profile> getAllProfile() {
		// TODO Auto-generated method stub
		return ht.loadAll(Profile.class);
	}
}
