package com.glats.setting.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "profile")
public class Profile {
	@Id
	@SequenceGenerator(name = "seqToken", sequenceName = "SEQ_TOKEN", initialValue = 100, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqToken")
	@Column(name = "profileId")
	private Integer profileId;
	@Column(name = "name")
	private String name;
	@Column(name = "gender")
	private String gender;
	@Column(name = "email")
	private String email;
	@Column(name = "language")
	private String language;
	@Column(name = "country")
	private String country;
	@Column(name = "mobile")
	private String mobile;

	public Profile() {
		super();
	}

	public Profile(Integer profileId) {
		super();
		this.profileId = profileId;
	}

	public Profile(Integer profileId, String name, String gender, String email, String language, String country,
			String mobile) {
		super();
		this.profileId = profileId;
		this.name = name;
		this.gender = gender;
		this.email = email;
		this.language = language;
		this.country = country;
		this.mobile = mobile;
	}

	public Integer getProfileId() {
		return profileId;
	}

	public void setProfileId(Integer profileId) {
		this.profileId = profileId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Profile [profileId=" + profileId + ", name=" + name + ", gender=" + gender + ", email=" + email
				+ ", language=" + language + ", country=" + country + ", mobile=" + mobile + "]";
	}

}