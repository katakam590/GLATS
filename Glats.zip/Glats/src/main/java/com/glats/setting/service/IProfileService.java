package com.glats.setting.service;

import java.util.List;

import com.glats.setting.model.Profile;


public interface IProfileService {
	  public Integer saveProfile(Profile profile) ;
	   public void updateProfile(Profile profile);
	   public void deleteProfile(Integer profileId);
	   public Profile getOneProfileById(Integer profileId);
	   public List<Profile>getAllProfile();
}
