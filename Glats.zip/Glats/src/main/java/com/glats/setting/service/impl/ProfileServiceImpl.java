package com.glats.setting.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glats.setting.dao.IProfileDao;
import com.glats.setting.model.Profile;
import com.glats.setting.service.IProfileService;


@Service
public class ProfileServiceImpl implements IProfileService {

	@Autowired
	private IProfileDao dao;

	@Transactional
	public Integer saveProfile(Profile profile) {
		return dao.saveProfile(profile);
	}

	@Transactional
	public void updateProfile(Profile profile) {
		dao.updateProfile(profile);		
	}

	@Transactional
	public void deleteProfile(Integer profileId) {
		dao.deleteProfile(profileId);		
	}

	@Transactional(readOnly=true)
	public Profile getOneProfileById(Integer profileId) {
		return dao.getOneProfileById(profileId);
	}

	@Transactional(readOnly=true)
	public List<Profile> getAllProfile() {
		return dao.getAllProfile();
	}

}
