package com.glats.setting.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.glats.setting.dao.IUserDao;
import com.glats.setting.model.User;
import com.glats.setting.service.IUserService;


@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	private IUserDao dao;

	@Transactional
	public Integer saveUser(User user) {
		return dao.saveUser(user);
	}

	@Transactional
	public void updateUser(User user) {
		dao.updateUser(user);		
	}

	@Transactional
	public void deleteUser(Integer userId) {
		dao.deleteUser(userId);		
	}

	@Transactional(readOnly=true)
	public User getOneUserById(Integer userId) {
		return dao.getOneUserById(userId);
	}

	@Transactional(readOnly=true)
	public List<User> getAllUser() {
		return dao.getAllUser();
	}

}
